import React from "react";
export default function SectionTitle({ kicker, title, subtitle, center }: { kicker?: string; title: string; subtitle?: string; center?: boolean }) {
  return (<div className={`mb-10 ${center ? "text-center" : ""}`}>
    {kicker && <div className="text-sm font-semibold uppercase tracking-widest text-orange-600">{kicker}</div>}
    <h2 className="mt-2 text-3xl font-bold tracking-tight text-zinc-900 sm:text-4xl">{title}</h2>
    {subtitle && <p className={`mt-3 text-zinc-600 ${center ? "mx-auto max-w-3xl" : ""}`}>{subtitle}</p>}
  </div>);
}