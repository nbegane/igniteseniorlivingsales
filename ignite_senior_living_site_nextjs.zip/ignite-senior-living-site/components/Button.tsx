import React from "react";
export default function Button({ children, href, variant = "primary", className = "" }: { children: React.ReactNode; href?: string; variant?: "primary" | "ghost"; className?: string }) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold transition";
  const styles = variant === "primary" ? "bg-zinc-900 text-white hover:bg-zinc-800" : "bg-transparent text-zinc-900 hover:bg-zinc-100";
  const Comp: any = href ? "a" : "button"; return <Comp href={href} className={`${base} ${styles} ${className}`}>{children}</Comp>;
}