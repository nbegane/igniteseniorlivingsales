# Ignite Senior Living Sales — Website (Next.js + Tailwind)
## Quick Start
npm install
npm run dev
## Customize
- app/page.tsx content
- Replace # links with your Calendly/LinkedIn/newsletter