import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "Ignite Senior Living Sales", description: "Turn tours into move-ins with hands-on, boutique consulting by Nick Begane, RCFE." };
export default function RootLayout({ children }: { children: React.ReactNode }) { return (<html lang="en"><body>{children}</body></html>); }