"use client";
import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Flame, Trophy, Linkedin, Mail, Calendar, CheckCircle2 } from "lucide-react";
import Container from "@/components/Container";
import SectionTitle from "@/components/SectionTitle";
import Card from "@/components/Card";
import Button from "@/components/Button";
export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50/50 via-white to-white text-zinc-900">
      <nav className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <Container className="flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Flame className="h-6 w-6 text-orange-600" />
            <span className="text-lg font-bold">Ignite Senior Living Sales</span>
          </div>
          <div className="hidden gap-6 text-sm font-medium md:flex">
            <a href="#services" className="hover:text-orange-600">Services</a>
            <a href="#programs" className="hover:text-orange-600">Programs</a>
            <a href="#proof" className="hover:text-orange-600">Results</a>
            <a href="#about" className="hover:text-orange-600">About</a>
            <a href="#contact" className="hover:text-orange-600">Contact</a>
          </div>
          <div className="flex items-center gap-3">
            <Button href="#contact" className="hidden md:inline-flex">Book a 1:1 <ArrowRight className="h-4 w-4" /></Button>
          </div>
        </Container>
      </nav>
      <header id="book" className="relative overflow-hidden">
        <Container className="grid items-center gap-10 py-16 sm:py-24 lg:grid-cols-2">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-xs font-medium text-orange-700 ring-1 ring-orange-200">
              <Flame className="h-4 w-4" /> Hands‑on, boutique consulting
            </div>
            <h1 className="mt-4 text-4xl font-extrabold tracking-tight sm:text-5xl">
              Turn tours into move-ins — with training that happens <span className="text-orange-600">in real life</span>.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-zinc-600">
              Ignite helps regional VPs and ownership groups lift occupancy with experiential sales coaching, a Virtual Sales Specialist service, and 90‑day turnaround programs led by <span className="font-semibold">Nick Begane, RCFE</span>.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button href="#contact">Schedule Intro Call <Calendar className="h-4 w-4" /></Button>
              <Button href="#newsletter" variant="ghost">Join Newsletter <Mail className="h-4 w-4" /></Button>
              <Button href="https://www.linkedin.com/in/" variant="ghost">Connect on LinkedIn <Linkedin className="h-4 w-4" /></Button>
            </div>
            <ul className="mt-6 grid max-w-xl grid-cols-1 gap-2 text-sm text-zinc-600 sm:grid-cols-2">
              {["Live tour coaching — learn by doing","Virtual Sales Specialist for coverage gaps","Recruiting & onboarding Sales Directors","SOP creation and implementation"].map((item) => (
                <li key={item} className="flex items-start gap-2"><CheckCircle2 className="mt-0.5 h-4 w-4 text-orange-600" /> {item}</li>
              ))}
            </ul>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}>
            <Card className="relative overflow-hidden">
              <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-orange-200/50 blur-3xl" />
              <div className="absolute -bottom-12 -right-12 h-40 w-40 rounded-full bg-orange-100 blur-3xl" />
              <h3 className="mb-2 text-lg font-semibold">Snapshot: Proven Authority</h3>
              <ul className="space-y-2 text-zinc-700">
                <li>• Turnaround: <strong>39% → near full</strong> occupancy</li>
                <li>• Led multiple high‑performing sales teams</li>
                <li>• <strong>2,500+ subscribers</strong> — Actionable Senior Living Tips</li>
                <li>• Licensed <strong>RCFE</strong>; Best of APFM awards; Community Business of the Year</li>
              </ul>
            </Card>
          </motion.div>
        </Container>
      </header>
      <section id="services" className="py-16 sm:py-24">
        <Container>
          <SectionTitle kicker="Services" title="Built for Operators & Ownership" subtitle="Training and support options that scale across portfolios — or go deep with a single community." center />
          <div className="grid gap-6 md:grid-cols-3">
            {[{title:"1:1 Coaching",desc:"Personalized weekly coaching for Sales Directors & EDs focusing on tour flow, objection handling, and closing."},{title:"Group Workshops",desc:"On‑site or virtual training to upskill teams with frameworks, role‑play, and live application."},{title:"Virtual Sales Specialist",desc:"Coverage when you’re understaffed — we handle inbound, tour scheduling, and sales follow‑through."},{title:"Recruiting & Onboarding",desc:"Source, hire, and ramp new Sales Directors with a proven 30‑60‑90 onboarding plan."},{title:"SOP Creation & Implementation",desc:"Codify your best practices and integrate them into daily rhythms with manager buy‑in."},{title:"Executive Advisory",desc:"Quarterly reviews and portfolio‑level insights for Regional VPs & PE backed platforms."}].map((s) => (
              <Card key={s.title}><h3 className="text-xl font-semibold">{s.title}</h3><p className="mt-2 text-sm text-zinc-600">{s.desc}</p></Card>
            ))}
          </div>
        </Container>
      </section>
      <section id="programs" className="bg-zinc-50 py-16 sm:py-24">
        <Container>
          <SectionTitle kicker="Programs" title="Packages That Drive Outcomes" subtitle="Choose a structured path or mix‑and‑match services to fit your operating plan." center />
          <div className="grid gap-6 md:grid-cols-2">
            <Card><h3 className="text-xl font-semibold">90‑Day Sales Turnaround</h3><ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-600">
              <li>Week 1–2: Audit, pipeline triage, SOP gaps</li><li>Week 3–6: Live tour coaching + follow‑up system</li><li>Week 7–12: Referral engine + leadership rhythms</li></ul>
              <div className="mt-4 flex gap-3"><Button href="#contact">Request Outline</Button><Button href="#contact" variant="ghost">Discuss Pricing</Button></div></Card>
            <Card><h3 className="text-xl font-semibold">Monthly Retainer</h3><ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-600">
              <li>Bi‑weekly coaching + quarterly portfolio review</li><li>Ongoing mystery shops & call scorecards</li><li>Hiring support + new‑hire onboarding</li></ul>
              <div className="mt-4 flex gap-3"><Button href="#contact">See Scope</Button><Button href="#contact" variant="ghost">Book Intro</Button></div></Card>
          </div>
        </Container>
      </section>
      <section id="proof" className="py-16 sm:py-24">
        <Container>
          <SectionTitle kicker="Results" title="Proof it Works" subtitle="Real numbers, real teams, real communities." center />
          <div className="grid gap-6 md:grid-cols-3">
            {[{ stat: "39% → ~100%", label: "Community Turnaround" },{ stat: "2,500+", label: "Newsletter Subscribers" },{ stat: "Multi‑State", label: "Teams Led & Trained" }].map((i) => (
              <Card key={i.label} className="text-center"><div className="text-3xl font-extrabold">{i.stat}</div><div className="mt-1 text-sm text-zinc-600">{i.label}</div></Card>
            ))}
          </div>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <Card><div className="flex items-center gap-3"><Trophy className="h-6 w-6 text-orange-600" /><h3 className="text-lg font-semibold">Awards & Credentials</h3></div>
              <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-600"><li>Licensed RCFE</li><li>Best of A Place for Mom (team awards)</li><li>Community Business of the Year — Mariposa at Ellwood Shores</li></ul></Card>
            <Card><h3 className="text-lg font-semibold">What Clients Say</h3><p className="mt-2 text-sm text-zinc-600">“Nick didn’t just train our team — he stood next to us on tours, modeled the close, and rebuilt our follow‑up. Our pipeline actually moves now.”</p><p className="mt-2 text-xs text-zinc-500">— Add operator name / title</p></Card>
          </div>
        </Container>
      </section>
      <section id="about" className="bg-zinc-50 py-16 sm:py-24">
        <Container>
          <SectionTitle kicker="About" title="Led by Nick Begane" subtitle="Regional Director of Sales & Marketing turned boutique consultant. I help operators turn tours into move‑ins with hands‑on, in‑the‑field coaching." center />
          <div className="mx-auto max-w-3xl text-center text-zinc-700">
            <p>I’ve held the same roles I coach — Sales Director and Regional. I built high‑performing teams across multiple states and led a flagship turnaround from 39% to near full during the hardest market in memory. Today, Ignite exists to bring that playbook to your communities, with sleeves‑rolled‑up implementation.</p>
          </div>
        </Container>
      </section>
      <section id="newsletter" className="py-16 sm:py-24">
        <Container>
          <SectionTitle kicker="Newsletter" title="Actionable Senior Living Tips" subtitle="Join 2,500+ operators and leaders who get practical, immediately‑usable sales ideas twice a month." center />
          <Card className="mx-auto max-w-2xl">
            <form className="flex flex-col gap-3 sm:flex-row" onSubmit={(e)=>e.preventDefault()}>
              <input type="text" placeholder="Your name" className="w-full rounded-xl border border-zinc-300 px-4 py-3 focus:border-orange-500 focus:outline-none" />
              <input type="email" placeholder="Work email" className="w-full rounded-xl border border-zinc-300 px-4 py-3 focus:border-orange-500 focus:outline-none" />
              <Button>Subscribe</Button>
            </form>
            <p className="mt-3 text-xs text-zinc-500">By subscribing you agree to receive occasional emails from Ignite. Unsubscribe anytime.</p>
          </Card>
        </Container>
      </section>
      <section id="contact" className="bg-zinc-50 py-16 sm:py-24">
        <Container>
          <SectionTitle kicker="Contact" title="Start a 1:1 Conversation" subtitle="Tell me about your portfolio and goals — I’ll share a quick plan and recommended next steps." center />
          <Card className="mx-auto max-w-2xl">
            <form className="grid grid-cols-1 gap-3 sm:grid-cols-2" onSubmit={(e)=>e.preventDefault()}>
              <input required placeholder="Full name" className="rounded-xl border border-zinc-300 px-4 py-3 focus:border-orange-500 focus:outline-none" />
              <input required type="email" placeholder="Work email" className="rounded-xl border border-zinc-300 px-4 py-3 focus:border-orange-500 focus:outline-none" />
              <input placeholder="Company / Portfolio" className="rounded-xl border border-zinc-300 px-4 py-3 focus:border-orange-500 focus:outline-none sm:col-span-2" />
              <textarea placeholder="What outcomes are you targeting in the next 90 days?" rows={4} className="rounded-xl border border-zinc-300 px-4 py-3 focus:border-orange-500 focus:outline-none sm:col-span-2" />
              <div className="sm:col-span-2 flex flex-wrap gap-3">
                <Button href="#">Send Inquiry <ArrowRight className="h-4 w-4" /></Button>
                <Button href="#" variant="ghost">Or book via Calendly</Button>
              </div>
            </form>
          </Card>
        </Container>
      </section>
      <footer className="border-t border-zinc-200 py-10">
        <Container className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-sm text-zinc-500">© {new Date().getFullYear()} Ignite Senior Living Sales. All rights reserved.</p>
          <div className="flex items-center gap-4 text-sm">
            <a className="hover:text-orange-600" href="#">Privacy</a>
            <a className="hover:text-orange-600" href="#">Terms</a>
            <a className="hover:text-orange-600" href="#">Accessibility</a>
          </div>
        </Container>
      </footer>
    </div>
  );
}